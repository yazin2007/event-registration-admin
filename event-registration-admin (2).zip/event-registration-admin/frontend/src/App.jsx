import { useCallback, useEffect, useMemo, useState } from 'react';
import { NavLink, Route, Routes, useNavigate, useParams } from 'react-router-dom';
import {
  CalendarDays, MapPin, Users, Plus, Search, Pencil, Trash2, LayoutDashboard,
  CalendarPlus, ArrowUpRight, Sparkles, X, ChevronRight, Clock3, Ticket
} from 'lucide-react';

const API = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';
const emptyForm = { name: '', description: '', date: '', venue: '' };

async function request(path, options = {}) {
  const response = await fetch(`${API}${path}`, {
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
    ...options
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || 'Something went wrong. Please try again.');
  return data;
}

function formatDate(date) {
  if (!date) return '—';
  return new Intl.DateTimeFormat('en', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(date));
}
function dateForInput(date) {
  if (!date) return '';
  const d = new Date(date);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function Shell({ children }) {
  return <div className="app-shell">
    <aside className="sidebar">
      <NavLink to="/" className="brand"><span className="brand-mark"><Sparkles size={20} /></span><span>gather<span className="brand-dot">.</span><small>EVENT CONSOLE</small></span></NavLink>
      <div className="side-label">WORKSPACE</div>
      <nav className="side-nav">
        <NavLink to="/" end className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}><LayoutDashboard size={18} />Dashboard</NavLink>
        <NavLink to="/add" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}><CalendarPlus size={18} />Add Event</NavLink>
      </nav>
      <div className="sidebar-bottom">
        <div className="help-card"><div className="help-icon"><Ticket size={18} /></div><strong>Make it memorable.</strong><p>Great events start with great planning.</p><span>YOU'VE GOT THIS <ArrowUpRight size={13} /></span></div>
        <div className="profile"><div className="avatar">A</div><div><strong>Administrator</strong><small>Event manager</small></div><span className="online-dot" /></div>
      </div>
    </aside>
    <main className="main-content">
      <header className="topbar"><div className="mobile-brand"><Sparkles size={18} /> gather<span>.</span></div><div className="breadcrumb">Workspace <ChevronRight size={14} /> <strong>Event management</strong></div><div className="topbar-right"><span className="status-dot" /> System operational <div className="top-avatar">A</div></div></header>
      <div className="page-wrap">{children}</div>
      <footer>© {new Date().getFullYear()} Gather Admin <span>Made for moments that matter <Sparkles size={12} /></span></footer>
    </main>
  </div>;
}

function Dashboard({ events, loading, onDelete, onEdit }) {
  const [search, setSearch] = useState('');
  const filtered = useMemo(() => events.filter(e => `${e.name} ${e.venue} ${e.eventId}`.toLowerCase().includes(search.toLowerCase())), [events, search]);
  const totalRegistrations = events.reduce((sum, e) => sum + (e.totalRegistrations || 0), 0);
  const upcoming = events.filter(e => new Date(e.date) >= new Date(new Date().setHours(0,0,0,0))).length;
  return <div className="fade-in">
    <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line" /> YOUR CONTROL CENTRE</div><h1>Event dashboard<span className="heading-period">.</span></h1><p className="subtitle">A little organisation goes a long way. Here's what's happening.</p></div><NavLink to="/add" className="primary-btn"><Plus size={17} /> Create event</NavLink></div>
    <section className="welcome-banner"><div className="banner-copy"><span className="banner-tag"><Sparkles size={13} /> YOUR EVENTS, AT A GLANCE</span><h2>Make every gathering<br /><em>count.</em></h2><p>Plan it. Host it. Remember it.</p></div><div className="banner-art" aria-hidden="true"><div className="art-circle circle-one" /><div className="art-circle circle-two" /><div className="art-calendar"><CalendarDays size={46} /><span>LET'S<br/>MEET</span></div><div className="art-star star-one">✳</div><div className="art-star star-two">✦</div><div className="art-dot" /></div></section>
    <section className="stats-grid">
      <div className="stat-card"><div className="stat-top"><span className="stat-icon lavender"><CalendarDays size={19}/></span><span className="stat-note">ALL TIME</span></div><div className="stat-number">{events.length.toString().padStart(2, '0')}</div><div className="stat-label">Total events <span>in your workspace</span></div></div>
      <div className="stat-card"><div className="stat-top"><span className="stat-icon mint"><Clock3 size={19}/></span><span className="stat-note">COMING UP</span></div><div className="stat-number">{String(upcoming).padStart(2, '0')}</div><div className="stat-label">Upcoming events <span>ready to happen</span></div></div>
      <div className="stat-card"><div className="stat-top"><span className="stat-icon peach"><Users size={19}/></span><span className="stat-note">ATTENDEES</span></div><div className="stat-number">{totalRegistrations.toLocaleString()}</div><div className="stat-label">Total registrations <span>across all events</span></div></div>
    </section>
    <section className="events-panel">
      <div className="panel-heading"><div><div className="eyebrow">THE LINE-UP</div><h2>Your events <span className="count-pill">{events.length}</span></h2></div><label className="search-box"><Search size={17}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search events..." aria-label="Search events" />{search && <button className="clear-search" onClick={() => setSearch('')} aria-label="Clear search"><X size={14}/></button>}</label></div>
      {loading ? <div className="loading-state"><span className="spinner"/>Loading your events...</div> : filtered.length === 0 ? <div className="empty-state"><div className="empty-icon"><CalendarDays size={25}/></div><h3>{search ? 'No matching events' : 'Your next great event starts here'}</h3><p>{search ? 'Try another event name or venue.' : 'Create an event and it will show up right here.'}</p>{!search && <NavLink to="/add" className="primary-btn"><Plus size={16}/> Add your first event</NavLink>}</div> : <div className="table-wrap"><table><thead><tr><th>EVENT DETAILS</th><th>EVENT DATE</th><th>VENUE</th><th>REGISTRATIONS</th><th className="actions-heading">ACTIONS</th></tr></thead><tbody>{filtered.map((event, index) => <tr key={event._id}><td><div className="event-cell"><div className={`event-thumb thumb-${index % 4}`}><CalendarDays size={19}/></div><div><strong>{event.name}</strong><small>{event.eventId || `EVT-${event._id.slice(-6).toUpperCase()}`}</small></div></div></td><td><span className="date-cell">{formatDate(event.date)}</span></td><td><span className="venue-cell"><MapPin size={14}/>{event.venue}</span></td><td><span className="registration-count"><Users size={14}/>{event.totalRegistrations || 0}</span></td><td><div className="action-group"><button className="icon-btn edit-btn" onClick={() => onEdit(event)} aria-label={`Edit ${event.name}`} title="Update event"><Pencil size={15}/></button><button className="icon-btn delete-btn" onClick={() => onDelete(event)} aria-label={`Delete ${event.name}`} title="Delete event"><Trash2 size={15}/></button></div></td></tr>)}</tbody></table></div>}
      <div className="panel-foot"><span>Showing <strong>{filtered.length}</strong> of <strong>{events.length}</strong> events</span><span><span className="foot-dot"/> All changes sync with your database</span></div>
    </section>
  </div>;
}

function EventForm({ initial, onSubmit, saving, error, onCancel }) {
  const [form, setForm] = useState(initial || emptyForm);
  useEffect(() => setForm(initial || emptyForm), [initial]);
  const update = e => setForm({ ...form, [e.target.name]: e.target.value });
  const submit = e => { e.preventDefault(); onSubmit(form); };
  return <div className="fade-in">
    <div className="page-heading"><div><div className="eyebrow"><span className="eyebrow-line"/> EVENT PLANNER</div><h1>{initial ? 'Edit your event' : 'Create an event'}<span className="heading-period">.</span></h1><p className="subtitle">{initial ? 'A few details changed? Keep your event up to date.' : 'Every unforgettable moment begins with a plan.'}</p></div><button className="secondary-btn" onClick={onCancel}><X size={16}/> Cancel</button></div>
    <div className="form-layout"><div className="form-main"><div className="form-card"><div className="form-card-heading"><div className="form-heading-icon"><CalendarPlus size={20}/></div><div><h2>Event details</h2><p>Fill in the essentials below.</p></div><span className="required-note">* Required</span></div>
      {error && <div className="error-banner" role="alert">{error}</div>}
      <form onSubmit={submit}>
        <div className="field"><label htmlFor="name">Event name <span>*</span></label><input id="name" name="name" value={form.name} onChange={update} placeholder="e.g. Creative Minds Meetup" maxLength="120" required/><small>Give your event a name people will remember.</small></div>
        <div className="field"><label htmlFor="description">Event description <span>*</span></label><textarea id="description" name="description" value={form.description} onChange={update} placeholder="What is this event about? Share a little detail..." rows="4" maxLength="2000" required/><small>A short description helps keep everything clear.</small></div>
        <div className="field-row"><div className="field"><label htmlFor="date">Event date <span>*</span></label><input id="date" name="date" type="date" value={form.date} onChange={update} required/><small>Choose the date of your event.</small></div><div className="field"><label htmlFor="venue">Venue <span>*</span></label><div className="input-with-icon"><MapPin size={16}/><input id="venue" name="venue" value={form.venue} onChange={update} placeholder="e.g. City Convention Hall" maxLength="180" required/></div><small>Where will it take place?</small></div></div>
        <div className="form-actions"><button type="button" className="secondary-btn" onClick={onCancel}>Cancel</button><button className="primary-btn" type="submit" disabled={saving}>{saving ? <><span className="button-spinner"/>Saving...</> : <><Plus size={16}/>{initial ? 'Save changes' : 'Create event'}</>}</button></div>
      </form>
    </div></div><aside className="form-aside"><div className="aside-art"><div className="aside-art-icon"><Sparkles size={27}/></div><span>THE LITTLE DETAILS</span><h3>Good things<br/>are <em>gathering.</em></h3><p>Bring people together around ideas, inspiration, and experiences worth sharing.</p><div className="aside-decoration">✳</div></div><div className="tip-card"><div className="tip-icon"><Users size={17}/></div><div><strong>Pro tip</strong><p>Use a clear event name and venue so your team can find the details quickly.</p></div></div></aside></div>
  </div>;
}

export default function App() {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState('');
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);
  const [editing, setEditing] = useState(null);
  const navigate = useNavigate();

  const notify = message => { setToast(message); window.setTimeout(() => setToast(''), 3200); };
  const loadEvents = useCallback(async () => {
    setLoading(true);
    try { setEvents(await request('/events')); }
    catch (e) { notify(e.message + ' Check that the backend and MongoDB Atlas are running.'); }
    finally { setLoading(false); }
  }, []);
  useEffect(() => { loadEvents(); }, [loadEvents]);

  const startEdit = event => { setEditing(event); setFormError(''); navigate(`/edit/${event._id}`); };
  const cancelForm = () => { setEditing(null); setFormError(''); navigate('/'); };
  const saveEvent = async form => {
    setSaving(true); setFormError('');
    try {
      if (editing) await request(`/events/${editing._id}`, { method: 'PUT', body: JSON.stringify(form) });
      else await request('/events', { method: 'POST', body: JSON.stringify(form) });
      await loadEvents();
      setEditing(null);
      notify(editing ? 'Event updated successfully.' : 'Your event has been created.');
      navigate('/');
    } catch (e) { setFormError(e.message); }
    finally { setSaving(false); }
  };
  const deleteEvent = async event => {
    if (!window.confirm(`Delete "${event.name}"? This action cannot be undone.`)) return;
    try { await request(`/events/${event._id}`, { method: 'DELETE' }); setEvents(current => current.filter(e => e._id !== event._id)); notify('Event deleted successfully.'); }
    catch (e) { notify(e.message); }
  };

  return <Shell>
    <Routes>
      <Route path="/" element={<Dashboard events={events} loading={loading} onDelete={deleteEvent} onEdit={startEdit}/>} />
      <Route path="/add" element={<EventForm key="add" initial={null} onSubmit={saveEvent} saving={saving} error={formError} onCancel={cancelForm}/>} />
      <Route path="/edit/:id" element={<EditRoute events={events} editing={editing} setEditing={setEditing} onSubmit={saveEvent} saving={saving} error={formError} onCancel={cancelForm}/>} />
      <Route path="*" element={<NotFound/>} />
    </Routes>
    {toast && <div className="toast" role="status"><span className="toast-check">✓</span>{toast}<button onClick={() => setToast('')} aria-label="Dismiss notification"><X size={15}/></button></div>}
  </Shell>;
}

function EditRoute({ events, editing, setEditing, onSubmit, saving, error, onCancel }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const event = editing?._id === id ? editing : events.find(e => e._id === id);
  useEffect(() => {
    if (event && editing?._id !== event._id) setEditing(event);
  }, [event, editing, setEditing]);
  if (!event) return <div className="empty-state route-empty"><div className="empty-icon"><CalendarDays size={25}/></div><h3>Event not found</h3><p>It may have been deleted or the page link is incorrect.</p><button className="primary-btn" onClick={() => navigate('/')}>Back to dashboard</button></div>;
  return <EventForm key={event._id} initial={{ name: event.name, description: event.description, date: dateForInput(event.date), venue: event.venue }} onSubmit={onSubmit} saving={saving} error={error} onCancel={onCancel}/>;
}
function NotFound() { return <div className="empty-state route-empty"><h3>Page not found</h3><p>Let's get you back to your events.</p><NavLink to="/" className="primary-btn">Go to dashboard</NavLink></div>; }
