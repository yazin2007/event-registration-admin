const express = require('express');
const mongoose = require('mongoose');
const Event = require('../models/Event');

const router = express.Router();

function serializeEvent(event) {
  return {
    _id: event._id,
    eventId: `EVT-${String(event._id).slice(-6).toUpperCase()}`,
    name: event.name,
    description: event.description,
    date: event.date,
    venue: event.venue,
    totalRegistrations: event.registrations?.length || 0,
    createdAt: event.createdAt,
    updatedAt: event.updatedAt
  };
}

router.get('/', async (_req, res, next) => {
  try {
    const events = await Event.find().sort({ date: 1 });
    res.json(events.map(serializeEvent));
  } catch (error) { next(error); }
});

router.get('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid event ID.' });
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ message: 'Event not found.' });
    res.json(serializeEvent(event));
  } catch (error) { next(error); }
});

router.post('/', async (req, res, next) => {
  try {
    const { name, description, date, venue } = req.body;
    if (![name, description, date, venue].every(value => typeof value === 'string' && value.trim())) {
      return res.status(400).json({ message: 'Event name, description, date, and venue are required.' });
    }
    const parsedDate = new Date(date);
    if (Number.isNaN(parsedDate.getTime())) return res.status(400).json({ message: 'Please provide a valid event date.' });
    const event = await Event.create({ name: name.trim(), description: description.trim(), date: parsedDate, venue: venue.trim() });
    res.status(201).json(serializeEvent(event));
  } catch (error) { next(error); }
});

router.put('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid event ID.' });
    const { name, description, date, venue } = req.body;
    if (![name, description, date, venue].every(value => typeof value === 'string' && value.trim())) {
      return res.status(400).json({ message: 'Event name, description, date, and venue are required.' });
    }
    const parsedDate = new Date(date);
    if (Number.isNaN(parsedDate.getTime())) return res.status(400).json({ message: 'Please provide a valid event date.' });
    const event = await Event.findByIdAndUpdate(
      req.params.id,
      { name: name.trim(), description: description.trim(), date: parsedDate, venue: venue.trim() },
      { new: true, runValidators: true }
    );
    if (!event) return res.status(404).json({ message: 'Event not found.' });
    res.json(serializeEvent(event));
  } catch (error) { next(error); }
});

router.delete('/:id', async (req, res, next) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) return res.status(400).json({ message: 'Invalid event ID.' });
    const event = await Event.findByIdAndDelete(req.params.id);
    if (!event) return res.status(404).json({ message: 'Event not found.' });
    res.json({ message: 'Event deleted successfully.' });
  } catch (error) { next(error); }
});

module.exports = router;
