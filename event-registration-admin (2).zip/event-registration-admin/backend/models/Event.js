const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  description: { type: String, required: true, trim: true, maxlength: 2000 },
  date: { type: Date, required: true },
  venue: { type: String, required: true, trim: true, maxlength: 180 },
  registrations: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Registration' }]
}, { timestamps: true });

module.exports = mongoose.model('Event', eventSchema);
