# Event Registration Admin Panel (MERN)

Responsive admin panel for creating, viewing, updating, and deleting events.

## Project structure
- `frontend/` — React + Vite
- `backend/` — Node.js + Express + Mongoose REST API

## Requirements
- Node.js 18+
- MongoDB Atlas account (or another MongoDB instance for local testing)

## 1. Configure the backend
Open `backend/.env` and replace the placeholder `MONGODB_URI` with your own **test** MongoDB Atlas connection string. The included value is only a placeholder and will not connect as-is.

## 2. Run the backend
```bash
cd backend
npm install
npm run dev
```
API defaults to `http://localhost:5000`.

## 3. Run the frontend
Open another terminal:
```bash
cd frontend
npm install
npm run dev
```
Open the local URL printed by Vite (usually `http://localhost:5173`).

## API endpoints
- `GET /api/events` — list events and registration counts
- `GET /api/events/:id` — get one event
- `POST /api/events` — create an event
- `PUT /api/events/:id` — update an event
- `DELETE /api/events/:id` — delete an event
- `GET /api/health` — API health check

## Notes for submission
- The `.env` file is included with a dummy placeholder, not working credentials. Set your own test Atlas URI before demonstrating or submitting.
- Never commit real passwords, access tokens, or production credentials to a public repository. If your assessment strictly requires an `.env` file, use a dedicated test database and rotate credentials after evaluation.
- `Total Registrations` is initialized to `0` for new events. The schema includes a registrations array, so it can be extended with registration records later.
